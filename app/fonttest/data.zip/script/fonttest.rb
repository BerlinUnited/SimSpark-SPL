# mount a standard file system
fontServer = new ('kerosin/FontServer', '/sys/server/font');
